from django.urls import path, include

urlpatterns = [
    path("", include("src.api.urls.cart")),
    path("", include("src.api.urls.billing")),
    path("", include("src.api.urls.product")),
    path("", include("src.api.urls.wishlist")),
]

from src.api.serializers.base import *


class BillingSerializer(BaseSerializer):
    class Meta:
        model = models.BillingDetail
        fields = "__all__"

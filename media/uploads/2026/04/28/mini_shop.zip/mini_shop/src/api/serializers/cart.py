from src.api.serializers.base import *


class CartAddSerializer(serializers.Serializer):
    product_id = serializers.IntegerField(default=0)


class CartQuantityUpdateSerializer(serializers.Serializer):
    item_id = serializers.IntegerField(default=0)
    type = serializers.ChoiceField(choices=['add', 'remove'], default="add")


class CartItemSerializer(BaseSerializer):
    class Meta:
        model = models.CartItem
        exclude = ("id", "cart")

    def to_representation(self, instance):
        data = super().to_representation(instance)
        data["product"] = ProductRelationSerializer(instance.product).data
        return data


class CartSerializer(BaseSerializer):
    class Meta:
        model = models.Cart
        fields = "__all__"

    def to_representation(self, instance):
        data = super().to_representation(instance)
        data["owner"] = UserRelationSerializer(instance.owner).data
        data["items"] = CartItemSerializer(instance.items.all(), many=True).data
        return data

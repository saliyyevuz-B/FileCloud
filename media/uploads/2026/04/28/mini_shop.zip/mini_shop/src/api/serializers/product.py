from src.api.serializers.base import *


class CategorySerializer(BaseSerializer):
    class Meta:
        model = models.Category
        fields = "__all__"


class ProductSerializer(BaseSerializer):
    class Meta:
        model = models.Product
        fields = "__all__"

    def to_representation(self, instance):
        data = super().to_representation(instance)
        data["category"] = CategoryRelationSerializer(instance.category).data
        return data

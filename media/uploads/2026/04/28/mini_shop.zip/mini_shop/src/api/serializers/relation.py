from rest_framework import serializers

import src.core.models as models


class UserRelationSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.User
        fields = ("id", "username")


class CategoryRelationSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Category
        fields = ("id", "name")


class ProductRelationSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Product
        fields = ("id", "name", "main_image", "price", "category", "stock")

    def to_representation(self, instance):
        data = super().to_representation(instance)
        data["category"] = CategoryRelationSerializer(instance.category).data
        return data

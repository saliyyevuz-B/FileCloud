from src.api.serializers.base import *


class WishlistSerializer(serializers.Serializer):
    product_id = serializers.IntegerField(default=0)


class LikedSerializer(BaseSerializer):
    class Meta:
        model = models.Wishlist
        exclude = ("user",)

    def to_representation(self, instance):
        data = super().to_representation(instance)
        data["product"] = ProductRelationSerializer(instance.product).data
        return data

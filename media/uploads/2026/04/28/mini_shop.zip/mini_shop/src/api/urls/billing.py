from django.urls import path

import src.api.views.billing as views

urlpatterns = [
    path("billing", views.BillingAPIView.as_view())
]

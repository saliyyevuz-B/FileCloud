from django.urls import path

import src.api.views.cart as views

urlpatterns = [
    path("cart", views.CartAPIView.as_view()),
    path("cart/add/", views.CardAddAPIView.as_view()),
    path("cart/quantity/update/", views.CartQuantityUpdateAPIView.as_view()),
]

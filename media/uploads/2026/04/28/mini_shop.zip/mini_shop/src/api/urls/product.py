from django.urls import path

import src.api.views.product as views

urlpatterns = [
    path("product/list", views.ProductListAPIView.as_view()),
    path("category/list", views.CategoryListAPIVIew.as_view()),
]

from django.urls import path

import src.api.views.wishlist as views

urlpatterns = [
    path("wishlist", views.LikedProductAPIView.as_view()),
    path("wishlist/add-remove", views.WishlistAddRemoveAPIView.as_view()),
]

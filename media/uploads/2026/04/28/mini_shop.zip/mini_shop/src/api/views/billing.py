from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response

import telebot
from django.conf import settings
from django.db import transaction
from drf_spectacular.utils import extend_schema

import src.utils as utils
import src.core.models as models
import src.api.serializers as serializers

token = settings.BOT_TOKEN
group_id = settings.GROUP_ID
bot = telebot.TeleBot(token)


class BillingAPIView(APIView):
    @extend_schema(
        request=serializers.BillingSerializer,
        responses=serializers.BillingSerializer)
    def post(self, request):
        data = request.data
        user = request.user
        try:
            cart = models.Cart.objects.filter(owner=user, is_active=True).last()
            items = models.CartItem.objects.filter(cart=cart)
            if cart is None or len(items) <= 0:
                return Response({"error": "Iltimos siz biron narsani cartga tanlang"},
                                status=status.HTTP_400_BAD_REQUEST)
            serializer = serializers.BillingSerializer(data=data)
            if serializer.is_valid():
                with transaction.atomic():
                    billing = serializer.save()
                    order = models.Order.objects.create(client=user, billing=billing, total_price=cart.total_price)
                    for i in items:
                        models.OrderItem.objects.create(
                            order=order,
                            product=i.product, price=i.price,
                            quantity=i.quantity, total_sum=i.total_sum
                        )
                    cart.is_active = False
                    cart.save()
                    text = utils.generated_order_text(order=order, items=items, billing=billing)
                    bot.send_message(chat_id=group_id, text=text, parse_mode="HTML")
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

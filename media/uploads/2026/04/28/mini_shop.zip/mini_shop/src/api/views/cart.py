from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated

from django.shortcuts import get_object_or_404
from drf_spectacular.utils import extend_schema

import src.core.models as models
import src.api.serializers as serializers


class CartAPIView(APIView):
    permission_classes = [IsAuthenticated]

    @extend_schema(responses=serializers.CartSerializer)
    def get(self, request):
        user = request.user
        cart, created = models.Cart.objects.get_or_create(owner=user, is_active=True)
        serializer = serializers.CartSerializer(cart)
        return Response(serializer.data, status=status.HTTP_200_OK)


class CardAddAPIView(APIView):
    @extend_schema(request=serializers.CartAddSerializer)
    def post(self, request):
        try:
            user = request.user
            product_id = request.data.get("product_id")  # 1
            product = get_object_or_404(models.Product, pk=product_id)
            cart, created = models.Cart.objects.get_or_create(owner=user, is_active=True)
            item, created = models.CartItem.objects.get_or_create(cart=cart, product=product)
            if not created:
                item.quantity += 1
                item.save()
            cart.calculate_total_price()
            return Response({"status": 1}, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({"status": 0, "msg": str(e)}, status.HTTP_400_BAD_REQUEST)


class CartQuantityUpdateAPIView(APIView):
    @extend_schema(request=serializers.CartQuantityUpdateSerializer)
    def post(self, request):
        try:
            action = request.data.get("type")  # [add, remove]
            item_id = request.data.get("item_id")  # 1
            item = get_object_or_404(models.CartItem, pk=item_id)
            cart = get_object_or_404(models.Cart, pk=item.cart.pk)
            if action == "add":
                item.quantity += 1
                item.save()

            elif action == "remove":
                item.quantity -= 1
                if item.quantity == 0:
                    item.delete()
                else:
                    item.save()
            else:
                return Response({"status": 0, "mgs": "type choice not found"}, status=status.HTTP_400_BAD_REQUEST)
            cart.calculate_total_price()
            return Response({"status": 1}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({"status": 0, "msg": str(e)}, status=status.HTTP_400_BAD_REQUEST)

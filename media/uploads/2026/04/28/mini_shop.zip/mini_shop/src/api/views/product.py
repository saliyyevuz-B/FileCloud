from rest_framework.generics import ListAPIView
from rest_framework.filters import SearchFilter
from django_filters.rest_framework import DjangoFilterBackend

import src.core.models as models
import src.api.serializers as serializer


class CategoryListAPIVIew(ListAPIView):
    queryset = models.Category.objects.all()
    serializer_class = serializer.CategorySerializer


class ProductListAPIView(ListAPIView):
    queryset = models.Product.objects.all()
    serializer_class = serializer.ProductSerializer
    filter_backends = (SearchFilter, DjangoFilterBackend)
    search_fields = ("name",)
    filterset_fields = ("category",)

from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated

from django.shortcuts import get_object_or_404
from drf_spectacular.utils import extend_schema

import src.core.models as models
import src.api.serializers as serializer


class WishlistAddRemoveAPIView(APIView):
    @extend_schema(request=serializer.WishlistSerializer)
    def post(self, request):
        user = request.user
        data: dict = request.data
        product_id: int = data.get("product_id")
        product = get_object_or_404(models.Product, pk=product_id)
        conn = models.Wishlist.objects.filter(user=user, product=product)
        if conn.exists():
            conn.delete()
            return Response({"status": 0}, status=status.HTTP_204_NO_CONTENT)
        else:
            models.Wishlist.objects.create(user=user, product=product)
            return Response({"status": 1}, status=status.HTTP_201_CREATED)


class LikedProductAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        object_list = models.Wishlist.objects.filter(user=user)
        serializers = serializer.LikedSerializer(object_list, many=True)
        return Response(serializers.data, status=status.HTTP_200_OK)

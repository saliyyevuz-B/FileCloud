from django.contrib import admin

import src.core.models as models


# Register your models here.


@admin.register(models.Category)
class CategoryAdmin(admin.ModelAdmin):
    search_fields = ("name",)
    list_filter = ("added_at",)
    list_display_links = ("id", "name")
    list_display = ("id", "name", "added_at", "updated_at")


@admin.register(models.Wishlist)
class WishlistAdmin(admin.ModelAdmin):
    pass


@admin.register(models.ProductImage)
class ProductImageAdmin(admin.ModelAdmin):
    ...


class ProductImageInline(admin.TabularInline):
    model = models.ProductImage
    extra = 1


@admin.register(models.Product)
class ProductAdmin(admin.ModelAdmin):
    inlines = (ProductImageInline,)
    search_fields = ("name",)
    readonly_fields = ("stock",)
    list_display_links = ("id", "name")
    list_filter = ("added_at", "is_active", "category")
    list_display = ("id", "name", "category", "price",
                    "income_price", "stock", "is_active", "added_at")


@admin.register(models.Cart)
class CartAdmin(admin.ModelAdmin):
    ...


@admin.register(models.CartItem)
class CartItemAdmin(admin.ModelAdmin):
    ...


@admin.register(models.BillingDetail)
class BillingDetailAdmin(admin.ModelAdmin):
    ...


@admin.register(models.Order)
class OrderAdmin(admin.ModelAdmin):
    ...


@admin.register(models.OrderItem)
class OrderItemAdmin(admin.ModelAdmin):
    ...

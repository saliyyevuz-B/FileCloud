import src.core.models as models


def variables(request):
    context = {
        "cart_item_count": 0,
        "category_list": models.Category.objects.all(),
    }
    if request.user.is_authenticated:
        cart = models.Cart.objects.filter(
            owner=request.user, is_active=True)
        if cart.exists():
            cart = cart.first().items.all().count()
        else:
            cart = 0
        context["cart_item_count"] = cart
    return context

from src.core.models.base import *


class BillingDetail(BaseModel):
    f_name = models.CharField(max_length=255)
    address = models.CharField(max_length=500)
    phone = models.CharField(max_length=15)
    extra_phone = models.CharField(max_length=15, null=True, blank=True)

    def __str__(self):
        return self.f_name


class Order(BaseModel):
    client = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name="orders")
    billing = models.ForeignKey(BillingDetail, on_delete=models.SET_NULL, null=True, related_name="orders")
    total_price = models.DecimalField(max_digits=16, decimal_places=2, default=0.00)

    def __str__(self):
        return f"{self.client}| ORDER ID: #{self.pk}"


class OrderItem(BaseModel):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="items")
    product = models.ForeignKey("Product", on_delete=models.SET_NULL, null=True, related_name="order_items")
    price = models.DecimalField(max_digits=16, decimal_places=2, default=0.00)
    quantity = models.PositiveIntegerField(default=1)
    total_sum = models.DecimalField(max_digits=16, decimal_places=2, default=0.00)

    def __str__(self):
        return f"ORDER ID: #{self.order.pk} | {self.product.name}"

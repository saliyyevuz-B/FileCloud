from src.core.models.base import *


class Category(BaseModel):
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name


class Product(BaseModel):
    name = models.CharField(max_length=255)
    main_image = models.ImageField(upload_to="products/main")
    category = models.ForeignKey(Category, on_delete=models.SET_NULL,
                                 null=True, related_name="products")
    price = models.DecimalField(max_digits=16, decimal_places=2, default=0.00)
    income_price = models.DecimalField(max_digits=16, decimal_places=2, default=0.00)
    stock = models.BigIntegerField(default=0)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.name


class ProductImage(BaseModel):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name="images")
    image = models.ImageField(upload_to="products/images")

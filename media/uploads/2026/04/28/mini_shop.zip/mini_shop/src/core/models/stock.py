from src.core.models.base import *


class StockIncome(BaseModel):
    product = models.ForeignKey("Product", on_delete=models.CASCADE,
                                related_name="stocks")
    quantity = models.BigIntegerField(default=0)
    price_per_item = models.DecimalField(max_digits=16, decimal_places=2, default=0.00)
    total_sum = models.DecimalField(max_digits=20, decimal_places=2, default=0.00)

    def save(
            self,
            force_insert=False,
            force_update=False,
            using=None,
            update_fields=None,
    ):
        self.product.stock += self.quantity
        self.product.save()
        super().save()

from django.db import models
from django.contrib.auth.models import User
from src.core.models.base import BaseModel


class Wishlist(BaseModel):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="wishlist")
    product = models.ForeignKey("Product", on_delete=models.CASCADE, related_name="wishlist")

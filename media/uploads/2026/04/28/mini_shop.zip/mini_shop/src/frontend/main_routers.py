from django.urls import path, include


urlpatterns = [
    path("", include("src.frontend.urls.cart")),
    path("", include("src.frontend.urls.auth")),
    path("", include("src.frontend.urls.order")),
    path("", include("src.frontend.urls.product")),
    path("", include("src.frontend.urls.wishlist")),
]

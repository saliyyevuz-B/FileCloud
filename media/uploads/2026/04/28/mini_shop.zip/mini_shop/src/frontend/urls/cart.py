from django.urls import path

import src.frontend.views.cart as views

urlpatterns = [
    path("cart/list", views.cart_list, name="cart_list"),
    path("add-to-cart/<int:product_id>", views.add_to_cart, name="add_to_cart"),

    path("remove-quantity/<int:item_id>", views.remove_to_cart, name="remove_quantity"),
    path("add-quantity/<int:item_id>", views.add_to_cart_in_cart_list, name="add_quantity"),
]

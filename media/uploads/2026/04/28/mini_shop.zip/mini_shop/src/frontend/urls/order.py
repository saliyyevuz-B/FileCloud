from django.urls import path

import src.frontend.views.order as views

urlpatterns = [
    path("checkout", views.checkout, name="checkout")
]

from django.urls import path

import src.frontend.views as views

urlpatterns = [
    path("", views.home),
    path("products-list", views.product_list, name="product_list"),
    path("products-list/search", views.product_search, name="product_search"),
    path("product-detail/<int:product_id>", views.product_detail, name="product_detail"),
    path("products-category-list/<int:category_id>",
         views.product_category_list, name="product_category"),
]

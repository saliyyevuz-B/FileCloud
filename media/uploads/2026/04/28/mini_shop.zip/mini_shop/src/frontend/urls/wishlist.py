from django.urls import path

import src.frontend.views.wishlist as views

urlpatterns = [
    path("add-remove-wishlist/<int:product_id>",
         views.add_remove_from_wishlist, name="add_remove_wishlist"),
    path("wishlist", views.wishlist, name="wishlist")
]

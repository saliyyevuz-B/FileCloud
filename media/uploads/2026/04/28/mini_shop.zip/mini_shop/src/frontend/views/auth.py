from django.shortcuts import redirect, render
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm


def register_view(request):
    if request.POST:
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("/login")
        else:
            return redirect("/register")
    form = UserCreationForm()
    return render(request, "form.html", {"form": form})


def login_view(request):
    if request.POST:
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get("username")
            password = form.cleaned_data.get("password")
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect("/")
            else:
                return redirect("login")
        else:
            return redirect("login")
    form = AuthenticationForm()
    return render(request, "form.html", {"form": form})


def logout_view(request):
    logout(request)
    return redirect("/")

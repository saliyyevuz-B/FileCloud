from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404

import src.core.models as models


@login_required(login_url="login")
def cart_list(request):
    user = request.user
    cart, created = models.Cart.objects.get_or_create(owner=user, is_active=True)
    items = models.CartItem.objects.filter(cart=cart)
    context = {
        "cart": cart,
        "items": items
    }
    return render(request, "cart.html", context)


@login_required(login_url="login")
def add_to_cart(request, product_id):
    user = request.user
    cart, created = models.Cart.objects.get_or_create(owner=user, is_active=True)
    product = get_object_or_404(models.Product, pk=product_id)
    cart_item, created = models.CartItem.objects.get_or_create(cart=cart, product=product)
    if not created:
        cart_item.quantity += 1
        cart_item.save()
    cart.calculate_total_price()
    return redirect("/")


@login_required(login_url="login")
def add_to_cart_in_cart_list(request, item_id):
    item = get_object_or_404(models.CartItem, pk=item_id)
    item.quantity += 1
    item.save()
    item.cart.calculate_total_price()
    return redirect("cart_list")


@login_required(login_url="login")
def remove_to_cart(request, item_id):
    item = get_object_or_404(models.CartItem, pk=item_id)
    item.quantity -= 1
    if item.quantity == 0:
        item.delete()
        item.cart.calculate_total_price()
        return redirect("cart_list")
    item.save()
    item.cart.calculate_total_price()
    return redirect("cart_list")

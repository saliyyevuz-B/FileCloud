from django.db import transaction
from django.contrib import messages
from django.shortcuts import redirect, render
from django.contrib.auth.decorators import login_required

import src.core.models as models


@login_required(login_url="login")
def checkout(request):
    user = request.user
    cart, _ = models.Cart.objects.get_or_create(owner=user, is_active=True)
    items = models.CartItem.objects.filter(cart=cart)
    if request.POST:
        if len(items) == 0:
            messages.info(request, "Iltimos biron narsa savatchaga qoshing")
            return redirect("/")
        with transaction.atomic():
            f_name = request.POST.get("f_name")
            address = request.POST.get("address")
            phone = request.POST.get("phone")
            extra_phone = request.POST.get("extra_phone")
            billing = models.BillingDetail.objects.create(
                f_name=f_name, address=address,
                phone=phone, extra_phone=extra_phone
            )
            order_obj = models.Order.objects.create(client=user, billing=billing, total_price=cart.total_price)
            for i in items:
                models.OrderItem.objects.create(
                    order=order_obj,
                    product=i.product,
                    price=i.price,
                    quantity=i.quantity,
                    total_sum=i.total_sum
                )
            messages.success(request, "Order muaffaqiyatli yuklandi siz bilan aloqaga chiqamiz!")
            cart.is_active = False
            cart.save()
            return redirect("/")
    context = {
        "cart": cart,
        "items": items
    }
    return render(request, "checkout.html", context)

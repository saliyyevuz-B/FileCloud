from django.shortcuts import render, redirect

import src.core.models as models


def home(request):
    last_products = models.Product.objects.all().order_by("-id")
    context = {
        "object_list": last_products
    }
    return render(request, "home.html", context)


def product_list(request):
    all_products = models.Product.objects.all().order_by("-id")
    context = {
        "object_list": all_products
    }
    return render(request, "home.html", context)


def product_category_list(request, category_id):
    all_products = models.Product.objects.filter(category_id=category_id).order_by("-id")
    context = {
        "object_list": all_products
    }
    return render(request, "home.html", context)


def product_detail(request, product_id):
    instance = models.Product.objects.get(id=product_id)
    context = {
        "object": instance
    }
    return render(request, "product_detail.html", context)


def product_search(request):
    search = request.GET.get("search")
    if search:
        object_list = models.Product.objects.filter(name__icontains=search)
        context = {"object_list": object_list}
        return render(request, "home.html", context)
    return redirect("/")

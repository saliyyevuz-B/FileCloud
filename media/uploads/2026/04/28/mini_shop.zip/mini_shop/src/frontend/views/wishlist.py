from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404

import src.core.models as models

@login_required(login_url="login")
def add_remove_from_wishlist(request, product_id):
    user = request.user
    product = get_object_or_404(models.Product, id=product_id)
    if models.Wishlist.objects.filter(user=user, product=product).exists():
        models.Wishlist.objects.filter(user=user, product=product).delete()
    else:
        models.Wishlist.objects.create(
            user=user, product=product
        )
    return redirect("/")


@login_required(login_url="login")
def wishlist(request):
    user = request.user
    wishlist_objects = models.Wishlist.objects.filter(user=user)
    product_ids = [] # [1, 9]
    for i in wishlist_objects:
        product_ids.append(i.product.id)
    object_list = models.Product.objects.filter(id__in=product_ids)
    context = {
        "object_list": object_list
    }
    return render(request, "home.html", context)

import src.core.models as models


def generated_order_text(
        order: models.Order,
        items: list[models.CartItem],
        billing: models.BillingDetail
) -> str:
    text = (f"<b>Yangi Buyurtma</b> #{order.pk}\n\n"
            f"<b>Buyurtmachi</b>: \n"
            f"<b>FIO:</b> {billing.f_name}\n"
            f"<b>Phone:</b> {billing.phone}\n"
            f"<b>ExPhone:</b> {billing.extra_phone}\n"
            f"<b>Address:</b> {billing.address}\n\n"
            f"<b>Buyurtma</b>:\n"
            f"<b>Umumiy Narx: </b>{order.total_price}$\n\n"
            f"<b>Maxsulotlar:</b>\n")
    for i in items:
        text += f"{i.product.name} {i.quantity}x{i.price}$ {i.total_sum}$\n"
    text += "\n\n"
    text += f"<a href='http://127.0.0.1:8000/admin/core/order/{order.pk}/change/'>Adminda ko'rish</a>"
    return text
